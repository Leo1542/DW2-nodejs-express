function formatarNome(nome){
console.log(nome.toLocaleUpperCase())

console.log(nome.toLowerCase())

console.log(nome.replace(/\s+/g, "").length);

}

formatarNome("Leonardo Vitorino")